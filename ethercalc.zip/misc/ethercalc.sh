#!/bin/sh

pushd ../ && docker-compose up -d && popd
